<?php  
include 'inc_conn_close.php';
include 'inc_javas.php';
?>