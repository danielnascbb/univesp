<?php

//select uf from `municipios_ibge` group by uf
?>