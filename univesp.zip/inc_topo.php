                   
<div class="row align-items-center">
    <!-- feriados
    <div class="col-3">
    <a href="feriados.php">Feriados / Recessos</a>
	</div>
    -->
    <div class="col-3">
    <a href="index.php">Cronograma</a>
	</div>
    <div class="col-3">
    <a href="instituicoes.php">Instituições</a>
	</div>
    <div class="col-2">
    <a href="turmas.php">Turmas</a>
    </div>
    <div class="col-2">
    <a href="aulas.php">Aulas</a>
    </div>
    <div class="col-2">
    <a href="login.php?logout=sim">Logout</a>
    </div>
</div>